var script = document.createElement('script');
script.src = 'https://p5play.org/v3/p5play.js';
document.head.appendChild(script);
console.error(
	'The file "https://p5play.org/v3/p5.play.js" has been moved. Please load p5play from this url: "https://p5play.org/v3/p5play.js"'
);
