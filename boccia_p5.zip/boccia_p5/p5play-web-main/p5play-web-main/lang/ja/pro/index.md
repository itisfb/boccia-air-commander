# 0-0

## p5play メンバーシップ

ゲームから実際の収益を得たいですか？

Pro メンバーになると、p5play を使って iOS アプリを作成できるようになります。これにより、Apple の App Store でゲームを販売したり、広告から収益を得ることが可能になります。

## 近日公開！

# 0-1

今すぐアカウントにサインアップして、Pro 機能が利用可能になった時に通知を受け取りましょう。

# 0-2

Pro 機能は[GitHub Sponsors](https://github.com/sponsors/quinton-ashley)または[Patreon](https://www.patreon.com/p5play)のメンバーにのみ利用可能になります。今すぐ参加して、p5play の開発をサポートしましょう！

支払いができない場合は、無料の[p5play 初心者ライセンス](https://github.com/quinton-ashley/p5play-novice/blob/main/LICENSE.md)を申請することができます。詳細は[LICENSING.md](https://github.com/quinton-ashley/p5play-web/blob/main/LICENSING.md)を参照してください。

# 1-0

## p5play

ようこそ！

サインアップしていただきありがとうございます。Pro 機能が利用可能になった際には、メールで通知されます！
