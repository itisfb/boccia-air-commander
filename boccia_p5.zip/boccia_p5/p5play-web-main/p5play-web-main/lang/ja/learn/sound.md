# 0-0

## 音

`loadSound` 関数を使用して `Sound` オブジェクトを作成します。

音を適切にミックスするためには、0 から 1 の範囲の値を受け入れる `setVolume` メソッドを使用することがよくあります。

より広範なオーディオミキシング機能については、[p5.sound](https://p5js.org/reference/#/libraries/p5.sound) ライブラリを使用できます。
