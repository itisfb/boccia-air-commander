# 0-0

## 学ぶ

これらの「学ぶ」リファレンスページは、p5play の最も重要な機能に対する対話型のミニ例を提供しています。

# 0-1

お探しの情報が見つからない場合は、[p5play の完全なドキュメンテーション](/docs/Sprite.html)、[p5.js リファレンス](https://p5js.org/reference/)、または [p5.sound リファレンス](https://p5js.org/reference/#/libraries/p5.sound) を試してみるか、[デモ](https://openprocessing.org/user/350295?o=35&view=sketches)を見てみてください。
