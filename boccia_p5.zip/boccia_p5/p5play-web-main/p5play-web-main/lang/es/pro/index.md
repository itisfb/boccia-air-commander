# 0-0

## Membresía p5play

¿Listo para ganar dinero real con tus juegos?

Como miembro Pro, podrás crear aplicaciones iOS usando p5play, lo que te permitirá vender tus juegos en la App Store de Apple o ganar ingresos a través de publicidad.

## ¡Próximamente!

# 0-1

Regístrate ahora para recibir notificaciones de cuando las funciones Pro estén disponibles.

# 0-2

Las funciones Pro solo estarán disponibles para los miembros de [GitHub Sponsors](https://github.com/sponsors/quinton-ashley) o [Patreon](https://www.patreon.com/p5play). ¡Únete ahora para apoyar el desarrollo de p5play!

Si no puedes permitirte pagar, puedes solicitar la [Licencia Novato de p5play](https://github.com/quinton-ashley/p5play-novice/blob/main/LICENSE.md) gratuita. Consulta [LICENSING.md](https://github.com/quinton-ashley/p5play-web/blob/main/LICENSING.md) para más información.

# 1-0

## Membresía p5play

¡Bienvenido!

Gracias por registrarte. ¡Serás notificado por correo electrónico cuando las funciones pro estén disponibles!
