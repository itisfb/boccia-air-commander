# 0-0

## Aprender

Estas páginas de referencia "Aprender" proporcionan mini ejemplos interactivos para las características más importantes de p5play.

# 0-1

¿No encuentras lo que buscas? Prueba la [documentación completa de p5play](/docs/Sprite.html), la [referencia de p5.js](https://p5js.org/reference/) o la [referencia de p5.sound](https://p5js.org/reference/#/libraries/p5.sound), o echa un vistazo a algunas [demostraciones](https://openprocessing.org/user/350295?o=35&view=sketches).
