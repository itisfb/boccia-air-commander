# 0-0

## Sonido

Utiliza la función `loadSound` para crear un objeto `Sound`.

A menudo, para mezclar sonidos adecuadamente, querrás usar el método `setVolume`, que acepta un valor en un rango de 0 a 1.

Para capacidades de mezcla de audio más extensas, puedes usar la biblioteca [p5.sound](https://p5js.org/reference/#/libraries/p5.sound).
